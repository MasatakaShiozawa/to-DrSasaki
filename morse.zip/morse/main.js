//Background
const SCREEN_W = 640;
const SCREEN_H = 360;

const FIELD_W = SCREEN_W;
const FIELD_H = SCREEN_H;

const CANVAS_W = SCREEN_W;
const CANVAS_H = SCREEN_H;

//CANVAS
let canvas = document.getElementById("canvas");
let con = canvas.getContext("2d");

canvas.width = CANVAS_W;
canvas.height = CANVAS_H;

//gameSpeed
const gameSpeed = 1000 / 60;

//keyboard condition
let key = [];

document.onkeydown = function (e) {
    key[e.keyCode] = true;
}

document.onkeyup = function (e) {
    key[e.keyCode] = false;
}

//FIELD
let vcanvas = document.createElement("canvas");
let vcon = vcanvas.getContext("2d");
vcanvas.width = FIELD_W;
vcanvas.height = FIELD_H;

//fnc rand()
function rand(MIN, MAX) {
    return Math.floor(Math.random() * (MAX - MIN + 1)) + MIN;
}

//no response 30flames => " "
let spacing = 20;
//1~60flames => ・

//60flames => —
let hyphen = 10;


let duration = 0;

let log = [];
let letter = [];
let lastkeystatus = false;
let keystatus = false;

let logCount = 0;

let frag = false;

let message = [];

let newINPUT = false;

function update() {
    if (key[32]) {
        keystatus = true;
    } else {
        keystatus = false;
    }

    if (!lastkeystatus) {
        if (!keystatus) {
            duration++;
            if (duration >= spacing) {
                if (log[log.length - 1] == "-" || log[log.length - 1] == "・") {
                    log.push("/");
                    frag = true;
                    console.log("/");
                }
                duration = 1;
            }
        } else {
            duration = 1;
        }

    } else {
        if (keystatus) {
            duration++;
        } else {
            if (duration >= hyphen) {
                log.push("-");
                console.log("-");
            } else {
                log.push("・");
                console.log("・");
            }

            duration = 1;
        }
    }

    lastkeystatus = keystatus;

    message = log.join("");
}

function changeToStack() {
    //  "/"がプッシュされたら
    if (frag) {
        letter = message.split("/");
        log = [];
        for (i = 0; i < letter.length; i++) {
            if (!letter[i]) {
                letter = letter.filter(function (letter) {
                    return letter !== "";
                });
            }
        }
        frag = false;
        newINPUT = true;
    }

}

let LETTER = [];

let result = "";

let newLETTER = false;

function changeToLetter() {
    let i = 0;
    while (newINPUT) {
        switch (letter[i]) {
            case "・----":
                LETTER.push("1");
                break;
            case "・・---":
                LETTER.push("2");
                break;
            case "・・・--":
                LETTER.push("3");
                break;
            case "・・・・-":
                LETTER.push("4");
                break;
            case "・・・・・":
                LETTER.push("5");
                break;
            case "-・・・・":
                LETTER.push("6");
                break;
            case "--・・・":
                LETTER.push("7");
                break;
            case "---・・":
                LETTER.push("8");
                break;
            case "----・":
                LETTER.push("9");
                break;
            case "-----":
                LETTER.push("0");
                break;





            case "・-":
                LETTER.push("a");
                break;
            case "-・・・":
                LETTER.push("b");
                break;
            case "-・-・":
                LETTER.push("c");
                break;
            case "-・・":
                LETTER.push("d");
                break;
            case "・":
                LETTER.push("e");
                break;
            case "・・-・":
                LETTER.push("f");
                break;
            case "--・":
                LETTER.push("g");
                break;
            case "・・・・":
                LETTER.push("h");
                break;
            case "・・":
                LETTER.push("i");
                break;
            case "・---":
                LETTER.push("j");
                break;
            case "-・-":
                LETTER.push("k");
                break;
            case "・-・・":
                LETTER.push("l");
                break;
            case "--":
                LETTER.push("m");
                break;
            case "-・":
                LETTER.push("n");
                break;
            case "---":
                LETTER.push("o");
                break;
            case "・--・":
                LETTER.push("p");
                break;
            case "--・-":
                LETTER.push("q");
                break;
            case "・-・":
                LETTER.push("r");
                break;
            case "・・・":
                LETTER.push("s");
                break;
            case "-":
                LETTER.push("t");
                break;
            case "・・-":
                LETTER.push("u");
                break;
            case "・・・-":
                LETTER.push("v");
                break;
            case "・--":
                LETTER.push("w");
                break;
            case "-・・-":
                LETTER.push("x");
                break;
            case "-・--":
                LETTER.push("y");
                break;
            case "--・・":
                LETTER.push("z");
                break;


            case "・-・-・-":
                LETTER.push(".");
                break;
            case "--・・--":
                LETTER.push(",");
                break;
            case "・・--・・":
                LETTER.push("?");
                break;
            case "・--・-・":
                LETTER.push("@");
                break;






            default:
                LETTER.push("*");
        }
        i++;
        newINPUT = false;
        newLETTER = true;
    }
    letter = [];

}

function clearBackGround() {
    con.fillStyle = "#0a0a2a";
    con.fillRect(0, 0, SCREEN_W, SCREEN_H);
}


function resetCheck() {
    if (key[82]) {
        LETTER = [];
        result = "";
        console.log("reseted");

    }
}

function drawText() {
    con.font = "32px serif";
    con.fillStyle = "#ffffff";

    con.textBaseline = "center";
    con.textAlign = "center";

    let x = (CANVAS_W / 2);
    let y = (CANVAS_H / 2);

    con.fillText(result, x, y);
}

//GameLoop
function gameLoop() {
    resetCheck();
    clearBackGround();
    update();
    changeToStack();
    changeToLetter();
    if (newLETTER) {
        result = LETTER.join("");
        console.log("log:" + result);
        newLETTER = false;
    }
    drawText();
}

//gameLoop
function gameInit() {
    setInterval(gameLoop, gameSpeed);
}

window.onload = function () {
    gameInit();
}