//enemy

class Enemy extends CharaBase{
    constructor(sn,x,y,vx,vy,kill){
        super(sn,x,y,vx,vy,kill);

        this.r=10;

        this.runaway = false;
    }
    update(){
        super.update();

        if(!this.runaway){
            if (player.x>this.x&&this.vy<120)this.vy+=6;
            else if (player.x<this.x&&this.vy<-120)this.vy-=6;
        }else{
            if (player.x<this.x&&this.vy<400)this.vx += 30;
            else if (player.x>this.x&&this.vy<-400)this.vx -= 30;
        }

        if(Math.abs(player.y-this.y)<(100<<8) && !this.runaway){
            this.runaway = true;

            let rad = Math.atan2(player.y-this.y,player.x-this.x);

            rad += rand(-20,20)*Math.PI/180;

            let dx = Math.cos(rad)*1000;
            let dy = Math.sin(rad)*1000;

            e_bullet.push(new E_bullet(15,this.x,this.y,dx,dy));
        }

        if(this.runaway&&this.vy>-800)this.vy-=30;
    }
    draw(){
        super.draw();
    }
}

class Boss extends CharaBase{
    constructor(sn,x,y,vx,vy,kill){
        super(sn,x,y,vx,vy,kill);

        this.r=10;

        this.runaway = false;
    }
    update(){
        super.update();

        if(!this.runaway){
            if (player.x>this.x&&this.vy<120)this.vy+=6;
            else if (player.x<this.x&&this.vy<-120)this.vy-=6;
        }else{
            if (player.x<this.x&&this.vy<400)this.vx += 30;
            else if (player.x>this.x&&this.vy<-400)this.vx -= 30;
        }

        if(Math.abs(player.y-this.y)<(100<<8) && !this.runaway){
            this.runaway = true;

            let rad = Math.atan2(player.y-this.y,player.x-this.x);

            rad += rand(-20,20)*Math.PI/180;

            let dx = Math.cos(rad)*1000;
            let dy = Math.sin(rad)*1000;

            e_bullet.push(new E_bullet(15,this.x,this.y,dx,dy));
        }

        if(this.runaway&&this.vy>-800)this.vy-=30;
    }
    draw(){
        super.draw();
    }
}

//Enemy bullet
class E_bullet extends CharaBase{
    constructor(sn,x,y,vx,vy,kill){
    super(sn,x,y,vx,vy,kill);

    }
}

let e_bullet = [];

let enemy = [];
