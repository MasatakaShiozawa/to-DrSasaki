//fncs
function rand(min,MAX){
    return Math.floor(Math.random()*(MAX-min+1))+min;
    }
    
let key = [];
document.onkeydown = function(e){
    key[e.keyCode] = true;
}    
document.onkeyup = function(e){
    key[e.keyCode] = false;
}        

function drawSptite(sn,x,y){
    let sx =sprite[sn].x;
    let sy =sprite[sn].y;
    let sw =sprite[sn].w;
    let sh =sprite[sn].h;
    
    let px = (x>>8)- sw/2;
    let py = (y>>8)- sh/2;
 
        if (px+sw<camera_x||px>camera_x+SCREEN_W+20||
            py+sh<camera_y||py>camera_y+SCREEN_H+20)return;

            VCONTEXT.drawImage(spriteImage,sx,sy,sw,sh,px,py,sw,sh);
            }
    
function updateObj(objectname){
    for(let i=objectname.length-1;i>=0;i--){
    objectname[i].update();
    if(objectname[i].kill)objectname.splice(i,1);}
}

function drawObj(objectname){
    for(let i=0;i<objectname.length;i++)objectname[i].draw();
}
function updateALL(){
        updateObj(star);
        updateObj(bullet);
        updateObj(enemy);
        updateObj(e_bullet);
        player.update();
}

function checkHit(x1,y1,r1,x2,y2,r2){
    let a = (x2-x1)>>8;
    let b = (y2-y1)>>8;
    let r = r1+r2;

    return r*r>=a*a+b*b;
}


function drawALL(){
    VCONTEXT.fillStyle=BGcolor;                 //clear BackGround
    VCONTEXT.fillRect(0,0,FIELD_W,FIELD_H);     //fill

    drawObj(star);
    drawObj(bullet);
    drawObj(enemy);
    drawObj(e_bullet);
    player.draw();
    
}
function cameraControl(){
    camera_x = (player.x>>8)/FIELD_W*(FIELD_W-SCREEN_W);
    camera_y = (player.y>>8)/FIELD_H*(FIELD_H-SCREEN_H);
}
function copyVCanvas(){
    CONTEXT.drawImage(VCANVAS,camera_x,camera_y,SCREEN_W,SCREEN_H,0,0,CANVAS_W,CANVAS_H);
}
function debugControl(){
    if(DEBUG){
        drawCount++;
        if(lastTime + 1000 <= Date.now()){
            fps = drawCount;
            drawCount = 0;
            lastTime = Date.now;
            //console.log("fps updated")
        }

        CONTEXT.font="30px";
        CONTEXT.fillStyle="white";
        CONTEXT.fillText("bullet="+bullet.length,5,10);
        CONTEXT.fillText("enemy="+enemy.length,5,20);
        CONTEXT.fillText("enemy bullet="+e_bullet.length,5,30);

        CONTEXT.fillText("fps="+fps,5,50);


    }
}
