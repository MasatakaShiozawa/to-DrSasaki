//DEGUG
let DEBUG = false;
let drawCount =0;
let fps = "not ready";
let lastTime=0;

    document.addEventListener("keydown",(debug)=>{
        if(debug.ctrlKey){
            DEBUG = !DEBUG;
            lastTime=Date.now();
            drawCount=0;
            fps = "not ready"
            if(DEBUG === true){
                console.log("debug on");
            }else{
                console.log("debug off");
            }
        }
    });    

    // document.addEventListener("keydown",function(){
    //     clearInterval(interval);
    //     gameInit();
    // });

  

//fnc gameLoop
function gameLoop(){
    if(rand(0,10)==1){
        enemy.push(new Enemy(rand(32,77),rand(0,FIELD_W)<<8,0,rand(-100,100),rand(100,900)));
    }
    updateALL();
    // checkKill();
    drawALL();
    cameraControl();
    copyVCanvas();
    debugControl();
    
}

//gameInit
function gameInit(){
    for (let i =0 ;i<star_MAX;i++)star[i] = new Star;
    let interval = setInterval(gameLoop,GAME_SPEED);
}


//GAME start at onload
window.onload = function(){
    gameInit();
}
