//const
const GAME_SPEED = 1000/60;
const BGcolor = "black"; 

//smoothing
const SMOOTHING = false;

//SCREEN,CANVAS,FIELD_SIZE
const SCREEN_W = 320;
const SCREEN_H = 320;

const FIELD_W  = 460;
const FIELD_H  = 400;

const CANVAS_W = 640;
const CANVAS_H = 640;

    //CANVAS ELEMENT
    let CANVAS = document.getElementById("display");
    let CONTEXT = CANVAS.getContext("2d");
    CANVAS.width = CANVAS_W;
    CANVAS.height= CANVAS_H;

    CONTEXT.mozimageSmoothingEnagbled   = SMOOTHING;
    CONTEXT.webkitimageSmoothingEnabled = SMOOTHING;
    CONTEXT.msimageSmoothingEnabled     = SMOOTHING;
    CONTEXT.imageSmoothingEnabled       = SMOOTHING;
    //VCANVAS VCONTEXT
    let VCANVAS = document.createElement("canvas");
    let VCONTEXT= VCANVAS.getContext("2d");
    VCANVAS.width = FIELD_W;
    VCANVAS.height= FIELD_H;


//CAMERA
let camera_x = 0;
let camera_y = 0;