class Sprite{
    constructor(x,y,w,h){
        this.x=x;
        this.y=y;
        this.w=w;
        this.h=h;
    }
}

//CharactorBase
class CharaBase{
    constructor(sn,x,y,vx,vy){
        this.x=x;
        this.y=y;
        this.vx=vx;
        this.vy=vy;

        this.sn = sn;

        this.kill = false;
    }

    update(){
        this.x += this.vx;
        this.y += this.vy;
        if(this.x<0||this.x>FIELD_W<<8||this.y<0||this.y>FIELD_H<<8){
                this.kill = true;
        }
    }

    draw(){
        drawSptite(this.sn,this.x,this.y);
    }

}
