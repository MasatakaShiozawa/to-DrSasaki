//Star
const star_MAX = 300;
let star = [];

class Star{
    constructor(){
        this.x = rand(0,FIELD_W)<<8;
        this.y = rand(0,FIELD_H)<<8;
        this.vx= 0 ;
        this.vy= rand(50,200);
        this.sz= rand(1,2);
        this.color = rand(1,9);
        this.twinkle = 0;
    }

    update(){
        this.x += this.vx;
        this.y += this.vy;
        if(this.y>FIELD_H<<8){
            this.y = 0;
            this.x = rand(0,FIELD_W)<<8;
        }
    }

    draw(){
        let x = this.x>>8;
        let y = this.y>>8;

        switch (this.color) {
            case 1:
                this.twinkle=rand(0,2);
                if(this.twinkle=0){
                VCONTEXT.fillStyle = "#ffffff";
                }else{
                VCONTEXT.fillStyle = "#f8f8ff";
                }
                break;
            case 2:
                this.twinkle=rand(0,2);
                if(this.twinkle=0){
                VCONTEXT.fillStyle = "#f0fff0";
                }else{
                VCONTEXT.fillStyle = "#40e0d0";
                }
                break;
            case 3:
                this.twinkle=rand(0,2);
                if(this.twinkle=0){
                VCONTEXT.fillStyle = "#da70d6";
                }else{
                VCONTEXT.fillStyle = "#8a2be2";
                }
                break;
            case 4:
                this.twinkle=rand(0,2);
                if(this.twinkle=0){
                VCONTEXT.fillStyle = "#f08080";
                }else{
                VCONTEXT.fillStyle = "#ff0000";
                }
                break;
            case 5:
                this.twinkle=rand(0,2);
                if(this.twinkle=0){
                VCONTEXT.fillStyle = "#87cefa";
                }else{
                VCONTEXT.fillStyle = "#00bfff";
                }
                break;
            case 6:
                this.twinkle=rand(0,2);
                if(this.twinkle=0){
                VCONTEXT.fillStyle = "#ffff00";
                }else{
                VCONTEXT.fillStyle = "#ffd700";
                }
                break;
            default:
                this.twinkle=rand(0,2);
                if(this.twinkle=0){
                VCONTEXT.fillStyle = "#afeeee";
                }else{
                VCONTEXT.fillStyle = "#00bfff";
                }
                break;
            }
        VCONTEXT.fillRect(x,y,this.sz,this.sz);
        
    }
}