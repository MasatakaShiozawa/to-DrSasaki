//Player
let spriteImage = new Image();
spriteImage.src ="sprite.png";

//class Bullet
class Bullet extends CharaBase{
    constructor(sn,x,y,vx,vy,kill){
        super(sn,x,y,vx,vy,kill);

        this.r=10;
    }

    update(){
        super.update();
        for (let i=0;i<enemy.length;i++){
            if(!enemy[i].kill){
                if(checkHit(this.x,this.y,this.r,enemy[i].x,enemy[i].y,enemy[i].r)){
                    enemy[i].kill=true;
                    this.kill=true;
                    break;
                }
            }
        }
    }
    draw(){
        super.draw();
    }
}

let bullet = [];

class Player{

    constructor(){
        this.x=(FIELD_W/2)<<8;
        this.y=(5*FIELD_H/6)<<8;

        this.speed = 512;

        this.anime = 0;

        this.reload1 = 0;
        this.reload2 = 0;
        
        this.kill = false;
    }

    update(){

        if (key[32] && this.reload1==0){
            bullet.push(new Bullet(5,this.x,this.y,0,-1500));
            this.reload1  = 2;
            this.reload2 ++;
            //console.log("relo1"+this.reload1);
            if(this.reload2==3){
                this.reload1 = 10;
                this.reload2 = 0;
                //console.log("relo1"+this.reload1);
            }
        }
        if(this.reload1>0)this.reload1--;

        if(key[37]&&this.x>this.speed){
            this.x -= this.speed;
            if(this.anime>-8)this.anime --;
        }else if(key[39] && this.x<=(FIELD_W<<8)-this.speed){
            this.x += this.speed;
            if(this.anime<8)this.anime ++;
        }else{
            if (this.anime<0)this.anime++;
            if(this.anime>0)this.anime --;
        }

        if(key[38]&&this.y>this.speed)this.y-=this.speed;
        if(key[40]&&this.y<=(FIELD_H<<8)-this.speed)this.y+=this.speed;
    }

    draw(){
            drawSptite(2+(this.anime>>2),this.x,this.y);
    }
}

let player= new Player;